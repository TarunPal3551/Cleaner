package appsforyou.cleanstudio.Classes;

public class power_item {

    String text;

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
