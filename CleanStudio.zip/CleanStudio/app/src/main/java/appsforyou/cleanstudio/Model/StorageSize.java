
package appsforyou.cleanstudio.Model;

public class StorageSize {


    public float value;

    public String suffix;

}
