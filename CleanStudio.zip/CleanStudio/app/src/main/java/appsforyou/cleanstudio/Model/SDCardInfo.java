package appsforyou.cleanstudio.Model;


public class SDCardInfo {
    public long total;

    public long free;
}
